package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

public class UsersDatabaseCode extends SQLiteOpenHelper {

    public static final String USER_TABLE = "USER_TABLE";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_PASSWORD = "PASSWORD";
    public static final String COLUMN_ID = "ID";
    private static UsersDatabaseCode usersInstance;

    public static synchronized UsersDatabaseCode getInstance (Context context) {
        // creates a singleton pattern so only one database of this kind is created
        if (usersInstance == null) {
            usersInstance = new UsersDatabaseCode(context.getApplicationContext());
        }
        return usersInstance;
    }

    private UsersDatabaseCode(@Nullable Context context) {
        super(context, "users.db", null, 1);
    }

    // called the first time the database is accessed
    @Override
    public void onCreate(SQLiteDatabase db) { // creates table called USER_TABLE with the 3 columns and increments the id by 1 each time something is added
        String createTableStatement = "CREATE TABLE " + USER_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createTableStatement);
    }

    // called if the database version number changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addUserToDb (UserModel userModel) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        // creates a ContentValues that stores the data of the new user and uses the column names as the keys for the values
        cv.put(COLUMN_USERNAME, userModel.getUsername());
        cv.put(COLUMN_PASSWORD, userModel.getPassword());

        long insert = db.insert(USER_TABLE, null, cv); // inserts user into database

        db.close();
        // returns if insert was successful or not
        if (insert == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    public UserModel getUserByID(int id) {
        UserModel foundUser;
        String queryString = "SELECT FROM " + USER_TABLE + " WHERE " + COLUMN_ID + " = " + id;
        // search database based on id
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) { // checks if cursor is not empty
            int userId = cursor.getInt(0);
            String userName = cursor.getString(1);
            String password = cursor.getString(2);

            foundUser = new UserModel(userId, userName, password); // creates new user model based on returned data

            cursor.close();
            db.close();
            return foundUser; // returns found user
        }
        else {
            return null;
        }
    }

    public UserModel getUserByName(String name) {
        UserModel foundUser;

        SQLiteDatabase db = this.getReadableDatabase();
        // search database based on username
        Cursor cursor = db.query(USER_TABLE, new String[] {COLUMN_ID, COLUMN_USERNAME, COLUMN_PASSWORD}, "USERNAME = ?", new String[] {name}, null, null, null);

        if (cursor.moveToFirst()) { // checks if cursor is not empty
            int userId = cursor.getInt(0);
            String userName = cursor.getString(1);
            String password = cursor.getString(2);

            foundUser = new UserModel(userId, userName, password); // creates new user model based on returned data

            cursor.close();
            db.close();
            return foundUser; // returns found user
        }
        else {
            return null;
        }


    }

    public boolean deleteOne (UserModel userModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        // searches database based on username to delete
        int delete = db.delete(USER_TABLE, "USERNAME = ?", new String[]{Integer.toString(userModel.getId())});
        db.close();

        if (delete == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateOne (UserModel userModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ID, userModel.getId());
        cv.put(COLUMN_USERNAME, userModel.getUsername());
        cv.put(COLUMN_PASSWORD, userModel.getPassword());
        // searches database based on username to update
        int update = db.update(USER_TABLE, cv, "USERNAME = ?", new String[] {Integer.toString(userModel.getId())});

        db.close();
        if (update == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    // code below is for encryption decryption of user data, still in development
    /*
    public String encryptPassword (String password, UsersDatabaseCode usersDatabaseCode) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException,
            KeyStoreException, IOException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, CertificateException, UnrecoverableKeyException, OperatorCreationException {

        UsersKeyStore usersKeyStore = UsersKeyStore.getInstance(this);
        InputStream keyStoreData = new FileInputStream("keystore.ks");

        String encryptedStorePassword = usersDatabaseCode.getUserByName("keyStorePass").getPassword();

        usersKeyStore.load(keyStoreData, this.decryptPassword(encryptedStorePassword, usersDatabaseCode).toCharArray());
        PrivateKey privateKey = (PrivateKey) usersKeyStore.getKey("KeyStorePrivate", this.decryptPassword(encryptedStorePassword, usersDatabaseCode).toCharArray());

        byte [] plainTextPassByte = password.getBytes();
        CIPHER.init(Cipher.ENCRYPT_MODE, privateKey);
        byte [] encryptedPassByte = CIPHER.doFinal(plainTextPassByte);
        Base64.Encoder encoder = Base64.getEncoder();
        String encryptedTextPass = encoder.encodeToString(encryptedPassByte);
        //KeyGenerator kGenerator = KeyGenerator.getInstance("AES");
        //kGenerator.init(256);

        //Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        //cipher.init(Cipher.ENCRYPT_MODE, key);

        return encryptedTextPass;
    }

    public String decryptPassword(String encryptedPass, UsersDatabaseCode usersDatabaseCode) throws BadPaddingException, IllegalBlockSizeException,
            NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException {

        System.out.println("IN DECRYPT");
        Base64.Decoder decoder = Base64.getDecoder();
        byte [] encryptedPassByte = decoder.decode(encryptedPass);
        String publicKeyString = usersDatabaseCode.getUserByName("publicKey").getPassword();
        byte[] publicByte = Base64.getDecoder().decode(publicKeyString);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey pubKey = (PublicKey) keyFactory.generatePublic(new X509EncodedKeySpec(publicByte));

        System.out.println("BEFORE CIPHER");

        CIPHER.init(Cipher.DECRYPT_MODE, pubKey);
        byte[] decryptedPassByte = CIPHER.doFinal(encryptedPassByte);
        String decryptedTextPass = new String(decryptedPassByte);

        //KeyGenerator kGenerator = KeyGenerator.getInstance("AES");
        //kGenerator.init(256);
        //Key key = kGenerator.generateKey();

        //Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        //cipher.init(Cipher.DECRYPT_MODE, key);

        return decryptedTextPass;
    }

    public String testEncryption (String password) throws NoSuchAlgorithmException, BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, InvalidKeyException {
        CIPHER = Cipher.getInstance("AES");
        KeyGenerator kGenerator = KeyGenerator.getInstance("AES");
        kGenerator.init(256);
        Key key = kGenerator.generateKey();

        //password.getBytes();
        //System.out.println(password);
        //String encryptedPassword = this.encryptPassword(password, key);
        //System.out.println(encryptedPassword);
        //return  encryptedPassword;
        return password;
    }

    public String testDecryption (String encryptedPass) throws NoSuchAlgorithmException, BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, InvalidKeyException {
        CIPHER = Cipher.getInstance("AES");
        KeyGenerator kGenerator = KeyGenerator.getInstance("AES");
        kGenerator.init(256);
        Key key = kGenerator.generateKey();

        //password.getBytes();
        System.out.println(encryptedPass);
        //String decryptedPassword = this.decryptPassword(encryptedPass, key);
        //System.out.println(decryptedPassword);
        //return  decryptedPassword;
        return encryptedPass;
    }*/
}

