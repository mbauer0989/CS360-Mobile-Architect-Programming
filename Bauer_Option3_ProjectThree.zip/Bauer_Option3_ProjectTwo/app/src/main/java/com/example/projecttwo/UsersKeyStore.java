package com.example.projecttwo;

import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.KeyStoreSpi;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.cert.CertificateException;

import javax.crypto.Cipher;

// this class is for encryption and decryption and is still in development
public class UsersKeyStore extends KeyStore {

    private static Cipher CIPHER;
    private static UsersKeyStore usersKeyStoreInstance;
    private static KeyPairGenerator keyGen;
    private static KeyPair pair;
    private static PrivateKey privateKey;
    private static PublicKey publicKey;


    public static synchronized void getInstance (UsersDatabaseCode usersDatabaseCode) throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
/*
        if (usersDatabaseCode.getUserByName("keyStorePass") == null) {

            Security.addProvider(new BouncyCastleProvider());

            KeyStore tempStore = KeyStore.getInstance(KeyStore.getDefaultType());
            tempStore.load(null, null);

            try {
                keyGen = KeyPairGenerator.getInstance("RSA");
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            System.out.println("BEFORE CERT Build");

            keyGen.initialize(1024);
            pair = keyGen.generateKeyPair();
            publicKey = pair.getPublic();
            privateKey = pair.getPrivate();

            X500Name issuer = new X500Name("CN=IamTheIssuer");
            BigInteger serial = BigInteger.valueOf(System.currentTimeMillis());
            X500Name subject = new X500Name("DC=SNHUApp");
            SubjectPublicKeyInfo subPubKeyInfo = SubjectPublicKeyInfo.getInstance(ASN1Sequence.getInstance(publicKey.getEncoded()));
            X509v3CertificateBuilder certBuild = new X509v3CertificateBuilder(issuer, serial, new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000),
                    new Date(System.currentTimeMillis() + 2 * 365 * 24 * 60 * 60 * 1000), subject, subPubKeyInfo);

            ContentSigner contentSign = new JcaContentSignerBuilder("SHA256WithRSAEncryption").build(privateKey);
            X509CertificateHolder certHold = certBuild.build(contentSign);
            Certificate cert = new JcaX509CertificateConverter().getCertificate(certHold);
            Certificate [] chain = new Certificate[] {cert};

            System.out.println("FINISHED CERT Build");

            byte[] array = new byte[15]; // length is bounded by 15
            new Random().nextBytes(array);
            String generatedString = new String(array, Charset.forName("UTF-8"));

            byte [] plainTextPassByte = generatedString.getBytes();
            try {
                CIPHER = Cipher.getInstance("RSA");
                CIPHER.init(Cipher.ENCRYPT_MODE, privateKey);
            } catch (InvalidKeyException e) {
                e.printStackTrace();
            } catch (NoSuchPaddingException e) {
                e.printStackTrace();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }

            byte [] encryptedPassByte = new byte[0];
            try {
                encryptedPassByte = CIPHER.doFinal(plainTextPassByte);
            } catch (BadPaddingException e) {
                e.printStackTrace();
            } catch (IllegalBlockSizeException e) {
                e.printStackTrace();
            }

            Base64.Encoder encoder = Base64.getEncoder();
            String encryptedTextPass = encoder.encodeToString(encryptedPassByte);

            char [] password = generatedString.toCharArray();

            System.out.println("IN USERS KEY");

            tempStore.setKeyEntry("KeyStorePrivate", privateKey, password, chain);

            System.out.println("AFTER SET KEY");

            try (FileOutputStream keyStoreOutputStream = new FileOutputStream("data/keystore.ks")) {
                tempStore.store(keyStoreOutputStream, password);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (CertificateException e) {
                e.printStackTrace();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }

            UserModel userModelStore = new UserModel(1, "keyStorePass", encryptedTextPass);
            UserModel userModelPublic = new UserModel(1, "publicKey", Base64.getEncoder().encodeToString(publicKey.getEncoded()));
            usersDatabaseCode.addUserToDb(userModelStore);
            usersDatabaseCode.addUserToDb(userModelPublic);
        }

        return usersKeyStoreInstance;*/
    }

    /**
     * Creates a KeyStore object of the given type, and encapsulates the given
     * provider implementation (SPI object) in it.
     *
     * @param keyStoreSpi the provider implementation.
     * @param provider    the provider.
     * @param type        the keystore type.
     */
    protected UsersKeyStore(KeyStoreSpi keyStoreSpi, Provider provider, String type) {
        super(keyStoreSpi, provider, type);
    }

    public void createKey (String name) {

    }
}
