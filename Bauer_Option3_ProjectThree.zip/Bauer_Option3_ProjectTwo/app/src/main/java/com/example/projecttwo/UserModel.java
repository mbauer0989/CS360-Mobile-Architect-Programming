package com.example.projecttwo;

public class UserModel {

    private int id;
    private String username;
    private String password;

    public UserModel(int id, String username, String password) { // method used when user model is created, gets id, username, password passed in
        this.id = id;
        this.username = username;
        this.password = password;
    }

    @Override
    public String toString() {
        return "UserModel{" +
                "id=" + id +
                ", username =" + username +
                ", password =" + password +
                '}';
    }

    public int getId() {
        return id;
    } // getter

    public String getUsername() {
        return username;
    } // getter

    public String getPassword() {
        return password;
    } // getter

    public void setId(int id) {
        this.id = id;
    } // setter

    public void setUsername(String username) {
        this.username = username;
    } // setter

    public void setPassword(String password) {
        this.password = password;
    } // setter
}
