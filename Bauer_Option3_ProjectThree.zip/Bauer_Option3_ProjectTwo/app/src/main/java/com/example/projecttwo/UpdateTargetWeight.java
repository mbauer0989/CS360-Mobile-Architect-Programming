package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UpdateTargetWeight extends AppCompatActivity {
    private EditText weight;
    private Bundle extras;
    private DatabaseCode databaseCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_target_weight);

        extras = getIntent().getExtras();
        weight = findViewById(R.id.editTargetWeightBox);
        // sets the EditText boxes to have the target weight from the table
        // this value was passed in as extras from another activity
        weight.setText(Integer.toString(extras.getInt("Weight")));
    }

    public void updateTargetWeight(View view) {
        WeightModel weightModel;

        try {// creates WeightModel based on what users enter in the boxes
            weightModel = new WeightModel(extras.getInt("ID"), Integer.valueOf(weight.getText().toString()), extras.getString("Date"));
        } catch (Exception e) {
            Toast.makeText(this, "Error Adding Weight", Toast.LENGTH_SHORT).show();
            weightModel = new WeightModel(-1, 0, "error");
        }

        databaseCode = DatabaseCode.getInstance(this);
        // calls update method and passes the Weight Model to it
        boolean toDb = databaseCode.updateOne(weightModel);

        Toast.makeText(this, "Added Target Weight = " + toDb, Toast.LENGTH_SHORT).show();

        Intent updateTargetWeightIntent = new Intent(UpdateTargetWeight.this, MainActivity.class);
        startActivity(updateTargetWeightIntent);
    }

    public void     cancelUpdateTargetWeight (View view)
    {
        Intent cancelTargetWeightIntent = new Intent(UpdateTargetWeight.this, MainActivity.class);
        startActivity(cancelTargetWeightIntent);
    }
}
