package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class FullWeightTable extends AppCompatActivity {

    private ListView lv_weightTable;
    private DatabaseCode databaseCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_table);

        databaseCode = DatabaseCode.getInstance(this);

        loadWeightTable(databaseCode);// calls method to load the table on the view full table activity

        ListView lv_weightList = findViewById(R.id.fullWeightTable);
        // sets up listener for user to click the table, row selected is sent to EditDeleteWeight class
        lv_weightList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                WeightModel clickedWeight = (WeightModel) parent.getItemAtPosition(position);
                Intent editDeleteWeightIntent = new Intent(FullWeightTable.this, EditDeleteWeight.class);
                editDeleteWeightIntent.putExtra("Weight", clickedWeight.getWeight()); // gets the data from selected row and stores it to be passed to new activity
                editDeleteWeightIntent.putExtra("Date", clickedWeight.getDate());
                editDeleteWeightIntent.putExtra("ID", clickedWeight.getId());
                startActivity(editDeleteWeightIntent);
            }
        });
    }

    private void loadWeightTable(DatabaseCode databaseCode) {
        // initializes a WeightAdapter that is used for the layout of the table and loads data based on weight_table.xml
        FullWeightAdapter adapter = new FullWeightAdapter(FullWeightTable.this, databaseCode);
        lv_weightTable = findViewById(R.id.fullWeightTable);
        lv_weightTable.setAdapter(adapter);
    }

    public void addWeight(View view) {
        // method that is used when the Add Weight button is clicked
        Intent addWeightIntent = new Intent(FullWeightTable.this, addWeight.class);
        startActivity(addWeightIntent);
    }

    public void backToMain(View view) {
        // method that is used when the back button is clicked
        Intent backToMain = new Intent(FullWeightTable.this, MainActivity.class);
        startActivity(backToMain);
    }
}
