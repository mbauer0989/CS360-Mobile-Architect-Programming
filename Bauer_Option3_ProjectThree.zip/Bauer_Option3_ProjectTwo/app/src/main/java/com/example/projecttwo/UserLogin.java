package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UserLogin extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private DatabaseCode databaseCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void checkUser (View view) {
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        UsersDatabaseCode usersDatabaseCode = UsersDatabaseCode.getInstance(this);
        databaseCode = DatabaseCode.getInstance(this);
        boolean registered = false;

        // checks if username that user entered exists in the database
        if (usersDatabaseCode.getUserByName(username.getText().toString()) == null) {
            // if it does not it calls the registerUser method and passes the username and password the user entered
            registered = registerUser(username.getText().toString(), password.getText().toString());

            if (databaseCode.getFullList().size() == 0 && registered) { // checks if the database is empty and the user was successfully registered
                Intent targetWeight = new Intent(UserLogin.this, TargetWeight.class); // brings user to the activity to enter target weight
                Toast toast = Toast.makeText(this, "You Are Registered\nWelcome " + username.getText().toString() + "\nPlease Enter Target Weight", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL, 50, 550);
                toast.show();
                startActivity(targetWeight);
            }
            else if (registered){ // if database is not empty and registered was successful goes straight to main activity
                Intent userLogin = new Intent(UserLogin.this, MainActivity.class);
                Toast.makeText(this, "You Are Registered\nWelcome " + username.getText().toString(), Toast.LENGTH_SHORT).show();
                startActivity(userLogin);
            }
        }
        else { // user already exists
            UserModel foundUser = usersDatabaseCode.getUserByName(username.getText().toString());

            if (!password.getText().toString().equals(foundUser.getPassword())) { // checks if password of user does not match password entered
                Toast.makeText(this, "Incorrect Password\nPlease Try Again", Toast.LENGTH_SHORT).show();
                password.getText().clear();
            }
            else if (databaseCode.getFullList().size() == 0) { // password entered matches, checks if database is empty
                Intent targetWeight = new Intent(UserLogin.this, TargetWeight.class); // brings user to the activity to enter target weight
                Toast toast = Toast.makeText(this, "Welcome " + username.getText().toString() + "\nPlease Enter Target Weight", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL, 50, 550);
                toast.show();
                startActivity(targetWeight);
            }
            else { // password entered matches, database is not empty, brings user to main activity
                Intent userLogin = new Intent(UserLogin.this, MainActivity.class);
                Toast.makeText(this, "Welcome " + username.getText().toString(), Toast.LENGTH_SHORT).show();
                startActivity(userLogin);
            }
        }
    }

    public boolean registerUser (String username, String userPassword) { // method to register user and save in database
        password = findViewById(R.id.password);

        if (username == null || username.length() < 4) { // checks if username is long enough
            Toast.makeText(this, "Invalid Username\nPlease Try Again", Toast.LENGTH_SHORT).show();
            password.getText().clear();
            return false;
        }
        else if (userPassword == null || userPassword.length() < 5) { // checks if password is long enough
            Toast.makeText(this, "Invalid Password\nPassword must be longer than 5 characters\nPlease Try Again", Toast.LENGTH_SHORT).show();
            password.getText().clear();
            return false;
        }
        else { // username and password are long enough, adds user to the database
            UsersDatabaseCode usersDatabaseCode = UsersDatabaseCode.getInstance(this);
            UserModel userModel = new UserModel(1, username, userPassword);
            boolean registered = usersDatabaseCode.addUserToDb(userModel);
            return registered;
        }
    }
}
