package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private DatabaseCode databaseCode;
    private ListView lv_weightTable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseCode = DatabaseCode.getInstance(this);

        loadWeightTable(databaseCode); // calls method to load the table on the main activity
        ListView lv_weightList = findViewById(R.id.weightTable);

        Toast toast= Toast.makeText(this, "Click to Edit Entry", Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL, 50, 550);
        toast.show();

        lv_weightList.setOnItemClickListener(new AdapterView.OnItemClickListener() { // sets up listener for user to click the table, row selected is sent to EditDeleteWeight class
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                WeightModel clickedWeight = (WeightModel) parent.getItemAtPosition(position);
                Intent editDeleteWeightIntent = new Intent(MainActivity.this, EditDeleteWeight.class);
                editDeleteWeightIntent.putExtra("Weight", clickedWeight.getWeight()); // gets the data from selected row and stores it to be passed to new activity
                editDeleteWeightIntent.putExtra("Date", clickedWeight.getDate());
                editDeleteWeightIntent.putExtra("ID", clickedWeight.getId());
                startActivity(editDeleteWeightIntent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        databaseCode = DatabaseCode.getInstance(this);

        lv_weightTable = findViewById(R.id.weightTable);

        loadWeightTable(databaseCode); // loads table on resume of main activity
    }

    private void loadWeightTable(DatabaseCode databaseCode) {
        // initializes a WeightAdapter that is used for the layout of the table and loads data based on weight_table.xml
        WeightAdapter adapter = new WeightAdapter(MainActivity.this, databaseCode);
        lv_weightTable = findViewById(R.id.weightTable);
        lv_weightTable.setAdapter(adapter);
    }

    public void loadFullWeightTable(View view) {
        // method that is used when the View All Entries button is clicked
        Intent loadFullWeightIntent = new Intent(MainActivity.this, FullWeightTable.class);
        startActivity(loadFullWeightIntent);
    }

    public void addWeight(View view) {
        // method that is used when the Add Weight button is clicked
        Intent addWeightIntent = new Intent(MainActivity.this, addWeight.class);
        startActivity(addWeightIntent);
    }

    public void askPermission(View view) {
        // method that is used when the Add Weight Reminder button is clicked
        RequestPerm requestPerm = new RequestPerm();
        requestPerm.askForPermission(this, MainActivity.this);
    }

    public void updateTargetWeight(View view) {
        // method that is used when the Update Target Weight button is clicked
        Intent updateTargetWeightIntent = new Intent(MainActivity.this, UpdateTargetWeight.class);
        databaseCode = DatabaseCode.getInstance(this);
        WeightModel targetWeight = databaseCode.getTargetWeight();

        // gets the data from target weight row and stores it to be passed to new activity
        updateTargetWeightIntent.putExtra("Weight", targetWeight.getWeight());
        updateTargetWeightIntent.putExtra("Date", targetWeight.getDate());
        updateTargetWeightIntent.putExtra("ID", targetWeight.getId());
        startActivity(updateTargetWeightIntent);
    }
}