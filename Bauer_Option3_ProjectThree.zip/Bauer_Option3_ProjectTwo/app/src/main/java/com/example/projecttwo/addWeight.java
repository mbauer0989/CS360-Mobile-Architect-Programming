package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class addWeight extends AppCompatActivity {

    private EditText newWeight;
    private EditText newDate;
    private DatabaseCode databaseCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);
    }

    public void submitWeight(View view) {
        newWeight = findViewById(R.id.addWeightBox);
        newDate = findViewById(R.id.addDateBox);

        WeightModel weightModel;

        try { // gets data the user entered to create a new Weight Model
            weightModel = new WeightModel(1, Integer.valueOf(newWeight.getText().toString()), newDate.getText().toString());
        }
        catch (Exception e) {
            Toast.makeText(this, "Error Adding Weight", Toast.LENGTH_SHORT).show();
            weightModel = new WeightModel(-1, 0, "error");
        }

        databaseCode = DatabaseCode.getInstance(this);

        boolean toDb = databaseCode.addWeightToDb(weightModel); // adds new weight to the database

        WeightModel targetWeight = databaseCode.getTargetWeight(); // creates Weight Model of target weight

        if (Integer.valueOf(newWeight.getText().toString()) == targetWeight.getWeight()) {
            RequestPerm requestPerm = new RequestPerm(); // compares target weight to weight being entered
            requestPerm.checkForPermission(this); // if they are equal it calls the method checkForPermission
        }

        Toast.makeText(this, "Success = " + toDb, Toast.LENGTH_SHORT).show();

        Intent addWeightIntent = new Intent(addWeight.this, MainActivity.class);
        startActivity(addWeightIntent);
    }

    public void cancelWeight(View view) // method called when cancel button is clicked
    {
        Intent cancelWeightIntent = new Intent(addWeight.this, MainActivity.class);
        startActivity(cancelWeightIntent);
    }
}