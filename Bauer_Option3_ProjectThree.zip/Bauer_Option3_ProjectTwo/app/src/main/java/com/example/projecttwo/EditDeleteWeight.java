package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditDeleteWeight extends AppCompatActivity {
    private EditText weight;
    private EditText date;
    private Bundle extras;
    private DatabaseCode databaseCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_delete_weight);

        // sets the EditText boxes to have the weight and date that was selected from the table
        // these values were passed in as extras from another activity
        extras = getIntent().getExtras();
        weight = findViewById(R.id.editWeightBox);
        date = findViewById(R.id.editDateBox);
        weight.setText(Integer.toString(extras.getInt("Weight")));
        date.setText(extras.getString("Date"));
    }

    public void updateWeight(View view) {
        WeightModel weightModel;

        try { // creates WeightModel based on what users enter in the boxes
            weightModel = new WeightModel(extras.getInt("ID"), Integer.valueOf(weight.getText().toString()), date.getText().toString());
        } catch (Exception e) {
            Toast.makeText(this, "Error Adding Weight", Toast.LENGTH_SHORT).show();
            weightModel = new WeightModel(-1, 0, "error");
        }

        databaseCode = DatabaseCode.getInstance(this);
        // calls update method and passes the Weight Model to it
        boolean toDb = databaseCode.updateOne(weightModel);

        Toast.makeText(this, "Added Weight = " + toDb, Toast.LENGTH_SHORT).show();

        Intent updateWeightIntent = new Intent(EditDeleteWeight.this, MainActivity.class);
        startActivity(updateWeightIntent);
    }

    public void deleteWeight(View view) {
        databaseCode = DatabaseCode.getInstance(this);
        // creates WeightModel based on what is in the boxes
        WeightModel weightModel = new WeightModel(extras.getInt("ID"), extras.getInt("Weight"), extras.getString("Date"));

        // calls delete method and passes the Weight Model to it
        if (databaseCode.deleteOne(weightModel)) {
            Toast.makeText(this, "Deleted Weight", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Did Not Delete Weight", Toast.LENGTH_SHORT).show();
        }

        Intent deleteWeightIntent = new Intent(EditDeleteWeight.this, MainActivity.class);
        startActivity(deleteWeightIntent);
    }

    public void cancelWeight(View view)
    {
        Intent cancelWeightIntent = new Intent(EditDeleteWeight.this, MainActivity.class);
        startActivity(cancelWeightIntent);
    }
}
