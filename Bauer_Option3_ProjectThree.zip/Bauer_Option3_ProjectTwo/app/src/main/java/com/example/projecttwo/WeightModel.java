package com.example.projecttwo;

import androidx.annotation.NonNull;

import java.util.Date;

public class WeightModel implements Comparable <WeightModel> {
    private int id;
    private int weight;
    private String date;

    public WeightModel(int id, int weight, String date) { // method used when weight model is created, gets id, weight, date passed in
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    @Override // method used to compare one weight model to another weight model based on the date
    public int compareTo(@NonNull WeightModel weightModel) {
        return this.date.compareTo(weightModel.date);
    }

    @Override
    public String toString() {
        return "WeightModel{" +
                "id=" + id +
                ", weight=" + weight +
                ", date=" + date +
                '}';
    }

    public int getId() {
        return id;
    } // getter

    public int getWeight() {
        return weight;
    } // getter

    public String getDate() {
        return date;
    } // getter

    public void setId(int id) {
        this.id = id;
    } // setter

    public void setWeight(int weight) {
        this.weight = weight;
    } // setter

    public void setDate(String date) {
        this.date = date;
    } // setter

}


