package com.example.projecttwo;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class WeightAdapter extends BaseAdapter {

    Activity myActivity;
    DatabaseCode databaseCode;

    public WeightAdapter(Activity myActivity, DatabaseCode databaseCode) {
        this.myActivity = myActivity;
        this.databaseCode = databaseCode;
    }

    @Override
    public int getCount() {
        return databaseCode.getLastSeven().size();
    }

    @Override
    public WeightModel getItem(int position) {
        return databaseCode.getLastSeven().get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override // sets the boxes in the weight_table.xml from the data returned, inflates the weight_table based on the data from getLastSeven method and the layout of weight_table.xml
    public View getView(int position, View convertView, ViewGroup parent) {
        View oneWeightLine;

        LayoutInflater inflater = (LayoutInflater) myActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        oneWeightLine = inflater.inflate(R.layout.weight_table, parent, false);

        TextView txtViewWeight = oneWeightLine.findViewById(R.id.txtViewWeight);
        TextView txtViewDate = oneWeightLine.findViewById(R.id.txtViewDate);

        WeightModel wm = this.getItem(position);

        txtViewWeight.setText(Integer.toString(wm.getWeight()));
        txtViewDate.setText(wm.getDate());

        return oneWeightLine;
    }
}
