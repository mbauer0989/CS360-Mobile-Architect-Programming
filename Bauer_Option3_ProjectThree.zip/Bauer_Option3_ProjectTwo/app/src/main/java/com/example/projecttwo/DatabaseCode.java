package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DatabaseCode extends SQLiteOpenHelper {

    public static final String COLUMN_WEIGHT = "WEIGHT";
    public static final String WEIGHT_TABLE = "WEIGHT_TABLE";
    public static final String COLUMN_DATE = "DATE";
    public static final String COLUMN_ID = "ID";
    private static DatabaseCode dbWeightInstance;

    public static synchronized DatabaseCode getInstance (Context context) {
        // creates a singleton pattern so only one database of this kind is created
        if (dbWeightInstance == null) {
            dbWeightInstance = new DatabaseCode(context.getApplicationContext());
        }
        return dbWeightInstance;
    }

    private DatabaseCode(@Nullable Context context) {
        super(context, "weight.db", null, 1);
    }

    // called the first time the database is accessed
    @Override
    public void onCreate(SQLiteDatabase db) { // creates table called WEIGHT_TABLE with the 3 columns and increments the id by 1 each time something is added
        String createTableStatement = "CREATE TABLE " + WEIGHT_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_WEIGHT + " INT, " + COLUMN_DATE + " TEXT)";
        db.execSQL(createTableStatement);
    }

    // called if the database version number changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addWeightToDb (WeightModel weightModel) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        // creates a ContentValues that stores the data of the new weight and uses the column names as the keys for the values
        cv.put(COLUMN_WEIGHT, weightModel.getWeight());
        cv.put(COLUMN_DATE, weightModel.getDate());

        long insert = db.insert(WEIGHT_TABLE, null, cv); // inserts weight into database

        db.close();
        // returns if insert was successful or not
        if (insert != -1) {
            return true;
        }
        else {
            return false;
        }
    }

    public WeightModel getTargetWeight() {
        String targetWeight = "Target Weight";
        WeightModel foundUser;

        SQLiteDatabase db = this.getReadableDatabase();
        // searches database based on the date value being the string Target Weight
        Cursor cursor = db.query(WEIGHT_TABLE, new String[] {COLUMN_ID, COLUMN_WEIGHT, COLUMN_DATE}, "DATE = ?", new String[] {targetWeight}, null, null, null);

        if (cursor.moveToFirst()) { // creates WeightModel to return based on Target Weight row
            int id = cursor.getInt(0);
            String weight = cursor.getString(1);
            String date = cursor.getString(2);

            foundUser = new WeightModel(id, Integer.valueOf(weight), date);

            cursor.close();
            db.close();
            return foundUser;
        }
        else {
            return null;
        }
    }

    public List<WeightModel> getLastSeven () {
        List<WeightModel> fullList = new ArrayList<>(); // this is needed otherwise fullList will not take on the list returned from getFullList
        List<WeightModel> returnList = new ArrayList<>();
        fullList = this.getFullList(); // returns the full list of weights
        WeightModel weightModel;

        // loop that gets up to the last 7 entered dates from the fullList
        for (int i = 1; i <= 7 && i <= fullList.size(); i++) {
                weightModel = fullList.get(fullList.size() - i);
                returnList.add(weightModel);
        }

        Collections.sort(returnList); // sorts the list
        Collections.reverse(returnList); // reverses the list so most recent is at the top
        return returnList;
    }

    public List<WeightModel> getFullList () {
        List<WeightModel> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + WEIGHT_TABLE; // searches for all of the entered data

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToLast()) {
            int i = 0;
            // loops for every row found in the database but skips the first because that is where the Target Weight is stored
            // creates a Weight Model, adds each to the returnlist
            for (cursor.moveToLast(); i < cursor.getCount() && !cursor.isFirst(); cursor.moveToPrevious()) {
                int weightId = cursor.getInt(0);
                int weight = cursor.getInt(1);
                String weightDate = cursor.getString(2);

                WeightModel newWeight = new WeightModel(weightId, weight, weightDate);
                returnList.add(newWeight);
                i++;
            }
        }

        cursor.close();
        db.close();
        Collections.sort(returnList);
        Collections.reverse(returnList);
        return returnList;
    }

    public boolean deleteOne (WeightModel weightModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        // deletes the specified weightModel that is passed in based on the id
        int delete = db.delete(WEIGHT_TABLE, "ID = ?", new String[]{Integer.toString(weightModel.getId())});
        db.close();

        if (delete == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateOne (WeightModel weightModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ID, weightModel.getId());
        cv.put(COLUMN_WEIGHT, weightModel.getWeight());
        cv.put(COLUMN_DATE, weightModel.getDate());
        // updates the specified weightModel that is passed in based on the id
        int update = db.update(WEIGHT_TABLE, cv, "ID = ?", new String[] {Integer.toString(weightModel.getId())});

        db.close();
        if (update == 1) {
            return true;
        }
        else {
            return false;
        }
    }
}
