package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TargetWeight extends AppCompatActivity {

    private EditText newWeight;
    private DatabaseCode databaseCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_target_weight);
    }

    public void submitTargetWeight(View view) {
        newWeight = findViewById(R.id.addTargetWeight);

        WeightModel weightModel;

        System.out.println("TEST SUBMIT TARGET " + Integer.valueOf(newWeight.getText().toString()));

        try { // gets the target weight the user entered to create a new Weight Model, date is "Target Weight" in order to uniquely identify it to search
            weightModel = new WeightModel(0, Integer.valueOf(newWeight.getText().toString()), "Target Weight");
        }
        catch (Exception e) {
            Toast.makeText(this, "Error Adding Weight", Toast.LENGTH_SHORT).show();
            weightModel = new WeightModel(-1, 0, "error");
        }

        databaseCode = DatabaseCode.getInstance(this);

        boolean toDb = databaseCode.addWeightToDb(weightModel); // adds target weight to the database as first row

        Toast.makeText(this, "Success = " + toDb, Toast.LENGTH_SHORT).show();

        Intent addTargetWeightIntent = new Intent(TargetWeight.this, MainActivity.class);
        startActivity(addTargetWeightIntent);
    }

    public void cancelTargetWeight(View view)
    {
        WeightModel weightModel;
        // sets the target weight as 0 to create a new Weight Model, date is "Target Weight" in order to uniquely identify it to search
        // this is a place holder since the user clicked cancel, the target weight row is added to the database with 0 as weight
        try {
            weightModel = new WeightModel(1, 0, "Target Weight");
        }
        catch (Exception e) {
            Toast.makeText(this, "Error Adding Weight", Toast.LENGTH_SHORT).show();
            weightModel = new WeightModel(-1, 0, "error");
        }

        databaseCode = DatabaseCode.getInstance(this);

        boolean toDb = databaseCode.addWeightToDb(weightModel); // adds target weight to the database as first row

        Intent cancelWeightIntent = new Intent(TargetWeight.this, MainActivity.class);
        startActivity(cancelWeightIntent);
    }
}
